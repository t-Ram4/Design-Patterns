package com.annathe.pattern;

public interface OS {
	
	public void spec();

}
