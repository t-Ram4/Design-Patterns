package com.annathe.pattern;

import java.util.ArrayList;
import java.util.List;

public class BillingSystemAdapter {
	
	public void processDetails(List<String[]> employees) {
		
		BillingSystem bs = new BillingSystem();
		
				
		List<Employee> empList = new ArrayList<Employee>();
		
		for(String[] e:employees) {
			
			Employee employee = new Employee();
			employee.setId(Integer.parseInt(e[0]));
			employee.setName(e[1]);
			employee.setDesignation(e[2]);
			empList.add(employee);
			
		}
		
		bs.processDetails(empList);
		
		
	}

}
