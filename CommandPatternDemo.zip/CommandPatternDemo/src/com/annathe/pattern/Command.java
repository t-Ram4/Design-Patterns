package com.annathe.pattern;

public interface Command {
	
	
	public void execute();

}
