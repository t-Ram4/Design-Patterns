package com.annathe.pattern;

public class ObserverPatternDemo {
	
	public static void main(String arg[]) {
		
		Subject subject  =  new Subject();
		
		Observer hexaObserver = new HexaObserver(subject);
		
		new BinaryObserver(subject);
		
		new OctaObserver(subject);
		
		System.out.println("First state change: 15");
		subject.setState(15);
		
		
		System.out.println("Second state change: 10");
		subject.setState(10);
		
		subject.unsubscribe(hexaObserver);
		
		System.out.println("Third state change: 5");
		subject.setState(5);
		
	}

}
