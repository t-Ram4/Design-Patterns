package com.annathe.pattern;

public class DatabaseHandler {
	
	int users;
	
	private static DatabaseHandler obj=new DatabaseHandler();
	
	
	private DatabaseHandler() {
		
	}

	
	public static DatabaseHandler getInstance() {
		
		return obj;
	}


public void connectDB() {
	
	++users;
	System.out.println("Connected to db");
	
	System.out.println("No of users connected "+ users);
}

}
