package com.annathe.pattern;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		DatabaseHandler dbhandler1 = DatabaseHandler.getInstance();
		
		DatabaseHandler dbhandler2 = DatabaseHandler.getInstance();
		
		
		if(dbhandler1==dbhandler2) {
			
			System.out.println("both objects are same");
		}
		
		dbhandler1.connectDB();
		dbhandler2.connectDB();
	}

}
