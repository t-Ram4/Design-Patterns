package com.annathe.pattern;

public class FactoryGenerator {
	
	public static AbstractDeviceFactory getFactory( String FactoryType) {
		
		
		switch(FactoryType) {
		
			case "Laptop":
					return new LaptopFactory();
		
			case "Mobile":
				return new MobileFactory();
		
		
		}

		return null;
		
	}

}
