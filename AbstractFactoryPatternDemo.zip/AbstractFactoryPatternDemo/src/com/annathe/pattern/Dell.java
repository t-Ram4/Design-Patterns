package com.annathe.pattern;

public class Dell extends Device {

	@Override
	public void getDetails() {
		
		System.out.println("DELL details");

	}

}
