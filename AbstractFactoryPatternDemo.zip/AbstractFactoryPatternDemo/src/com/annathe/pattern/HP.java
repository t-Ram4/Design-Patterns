package com.annathe.pattern;

public class HP extends Device {

	@Override
	public void getDetails() {
		
		System.out.println("HP details");

	}

}
