package com.annathe.pattern;

public  abstract class AbstractDeviceFactory {
	
	public abstract Device getGadget(String deviceType);

}
