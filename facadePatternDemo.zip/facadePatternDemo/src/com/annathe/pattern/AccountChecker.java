package com.annathe.pattern;

public class AccountChecker {
	
	public void checkAccount(int accountNo) {
		
		System.out.println("Account no is checked");
	}

}
