package com.annathe.pattern;

public class FundChecker {
	
	public void withdrawMoney(int amoubt) {
		
		System.out.println("Money withdrawn");
	}
	
	public void checkBalance(int amount) {
		
		System.out.println("Balance is verified");
	}

}
