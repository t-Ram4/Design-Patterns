package com.annathe.pattern;

public class BankAccountFacade {
	
	
	public boolean withdrawMoney(int amount) {
		
		
		AccountChecker ac = new AccountChecker();
		
		ac.checkAccount(7768);
		
		
		SecurityChecker s = new SecurityChecker();
		
		s.authenticate("ramab", "welcome123");
		
		FundChecker f = new FundChecker();
		
		f.checkBalance(amount);
		
		f.withdrawMoney(amount);
		
		return true;
	}

}
