package com.annathe.pattern;

public class ComponentB extends Component {

	public ComponentB(Mediator m) {
		
		super("Component-B",m);
	}
	
	
	@Override
	public void send() {
		String message ="Hello how r u";
		
		System.out.println("Component B is sending "+message);
		mediator.notify(this,message);

	}

	@Override
	public void receive(String message) {
		// TODO Auto-generated method stub
		System.out.println("Component B received the message "+message);
	}

}
