package com.annathe.pattern;

import java.util.HashMap;
import java.util.Map;

public class ConcreteMediator implements Mediator {
	
	private  final String COMPONENTA = "Component-A";
			
	private  final String COMPONENTB = "Component-B";
	
	private Map<String,Component> regCompMap = new HashMap();
	
	
	@Override
	public void notify(Component sender, String message) {
		String senderName = sender.getName();
		
		if(COMPONENTA.equals(senderName)) {
			
			this.reactOnA(message);
		}
		
		else if(COMPONENTB.equals(senderName)) {
			
			this.reactOnB(message);
		}
	}

	@Override
	public void register(Component comp) {
		
		regCompMap.put(comp.getName(), comp);
		

	}
	
	public void reactOnA(String message) {
		
		System.out.println("Mediator is in action");
		
			
		regCompMap.get(COMPONENTB).receive(message);
		
		
	}

public void reactOnB(String message) {
		
		System.out.println("Mediator is in action");
		
		
		regCompMap.get(COMPONENTA).receive(message);
		
		
	}
}
