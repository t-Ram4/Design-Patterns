package com.annathe.pattern;

public interface Mediator {
	
	public void notify(Component sender, String message);
	
	public void register(Component comp);

}
