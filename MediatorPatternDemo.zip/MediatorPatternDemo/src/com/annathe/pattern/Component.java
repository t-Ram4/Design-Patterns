package com.annathe.pattern;

public abstract class Component {
	
	String name;
	
	protected Mediator mediator;

	public Component(String name, Mediator mediator) {
		super();
		this.name = name;
		this.mediator = mediator;
	}
	
	
	
	public abstract void send();
	
	public abstract void receive(String message);

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	
	

}
