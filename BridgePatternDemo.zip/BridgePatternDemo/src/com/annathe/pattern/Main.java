package com.annathe.pattern;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Payment order = new CardPayment();
		
		order.iPaymentSystem = new IDBIPaymentSystem();
		
		order.makePayment();

	}

}
