package com.annathe.pattern;

public class IDBIPaymentSystem implements IPaymentSystem {

	@Override
	public void processPayment(String paymentSystem) {
		// TODO Auto-generated method stub
		System.out.println("Using IDBI gateway for "+paymentSystem);
	}

}
