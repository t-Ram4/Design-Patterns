package com.annathe.pattern;

public class CitiPaymentSystem implements IPaymentSystem {

	@Override
	public void processPayment(String paymentSystem) {
		// TODO Auto-generated method stub
		System.out.println("Using citibank gateway for "+paymentSystem);
	}

}
