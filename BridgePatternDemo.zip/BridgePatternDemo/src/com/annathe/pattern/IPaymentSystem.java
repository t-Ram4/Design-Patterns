package com.annathe.pattern;

public interface IPaymentSystem {
	
	public void processPayment(String paymentSystem);

}
