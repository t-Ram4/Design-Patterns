package com.annathe.pattern;

public class NetbankingPayment extends Payment {

	@Override
	public void makePayment() {
		
		iPaymentSystem.processPayment("Netbanking Payment");
		

	}

}
