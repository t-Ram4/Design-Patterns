package com.annathe.pattern;

public class CardPayment extends Payment {

	@Override
	public void makePayment() {
		
		iPaymentSystem.processPayment("CardPayment");
		

	}

}
