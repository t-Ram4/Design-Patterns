package com.annathe.pattern;

public class Client {
	
	public static void main(String arg[]) {
		
		PlainPizza p = new PlainPizza();
		
		String plainPizza = p.makePizza();
		
		System.out.println(plainPizza);
		
		String vegPizza = new VegPizzaDecorator(p).makePizza();
		
		System.out.println(vegPizza);
		
		String NonvegPizza = new ChickenPizzaDecorator(p).makePizza();
		
		System.out.println(NonvegPizza);
		
	}

}
