package com.annathe.pattern;

public interface Pizza {
	
	public String makePizza();

}
