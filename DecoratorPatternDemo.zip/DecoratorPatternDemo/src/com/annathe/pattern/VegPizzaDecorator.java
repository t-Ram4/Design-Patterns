package com.annathe.pattern;

public class VegPizzaDecorator extends PizzaDecorator {

	public VegPizzaDecorator(Pizza pizza) {
		super(pizza);
		// TODO Auto-generated constructor stub
	}
	
	
	public String makePizza() {
		// TODO Auto-generated method stub
		return "Plain Pizza" +addVeg();
	}


	public String addVeg() {
		
		return " Cheesse added "+"Onion added";
	}

}
