package com.annathe.pattern;

public class PlainPizza implements Pizza {

	@Override
	public String makePizza() {
		// TODO Auto-generated method stub
		return "Plain Pizza";
	}

}
